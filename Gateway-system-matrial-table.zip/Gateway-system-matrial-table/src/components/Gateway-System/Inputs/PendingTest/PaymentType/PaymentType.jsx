import { useEffect } from "react";
import PropTypes from "prop-types";
import Select from "../../Select";
import {
  createPaymentType,
  fetchPaymentType,
} from "@src/store/reducers/PendingTestList/PendingTestSlice";
import { useDispatch, useSelector } from "react-redux";
import { MdPayment } from "react-icons/md";
import { ToastSuccess } from "@src/util/Toast";

const PaymentType = ({ onChange, defaultValue }) => {
  const dispatch = useDispatch();
  const { payments, isLoading } = useSelector((state) => state.pendingTestList);

  useEffect(() => {
    dispatch(fetchPaymentType());
  }, [dispatch]);

  const createNewPayment = (data) => {
    dispatch(createPaymentType({ payment_type: data }))
      .unwrap()
      .then(({ message }) => {
        ToastSuccess(message);
        dispatch(fetchPaymentType());
      });
  };

  return (
    <Select
      id="payment_type"
      name="Payment Type"
      label="Payment Type (Optional)"
      options={
        payments?.map((payment) => ({
          id: payment.id,
          label: payment.payment_title,
        })) || []
      }
      placeholder="Payment Type"
      Icon={<MdPayment size={23} />}
      Button={true}
      defaultValue={defaultValue}
      required={false}
      onChange={onChange}
      onSubmitNew={createNewPayment}
      isLoading={isLoading}
    />
  );
};

PaymentType.propTypes = {
  onChange: PropTypes.func,
  defaultValue: PropTypes.string,
};

export default PaymentType;
