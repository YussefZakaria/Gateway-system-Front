import propTypes from "prop-types";
import {
  FormControl,
  FormLabel,
  TextField,
  Autocomplete,
  InputAdornment,
  Box,
} from "@mui/material";
import { useState } from "react";
import Spinner from "../Spinner/Spinner";

const Select = ({
  id,
  name,
  label,
  options,
  defaultValue,
  value,
  Error,
  Icon,
  placeholder,
  Button,
  required,
  onChange,
  onSubmitNew,
  loading,
}) => {
  const [add, setAdd] = useState(false);
  const [newOption, setNewOption] = useState("");

  const handlerNewAdd = () => {
    if (newOption) {
      onSubmitNew(newOption);
    }
    setNewOption("");
  };

  return (
    <FormControl sx={{ gap: "10px", width: "100%" }}>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 1,
        }}
      >
        <FormLabel htmlFor={id} sx={{ color: "var(--text-input)" }}>
          {label}
        </FormLabel>
        {Button && (
          <button
            type="button"
            style={{
              background: "var(--bg-button)",
              padding: "8px 20px",
              color: "var(--text-white)",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
            }}
            onClick={() => setAdd(!add)}
          >
            {!add ? "Add" : "Remove"}
          </button>
        )}
      </Box>

      {add ? (
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <TextField
            name={`new${name || id}`}
            fullWidth
            placeholder={`Add new  ${name || id}`}
            sx={{
              bgcolor: "var(--bg-input)",
            }}
            value={newOption}
            onChange={(e) => setNewOption(e.target.value)}
          />
          <button
            type="button"
            style={{
              background: "var(--bg-button)",
              padding: "8px 10px",
              color: "var(--text-white)",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
            }}
            onClick={handlerNewAdd}
          >
            {loading ? <Spinner /> : "Save"}
          </button>
        </Box>
      ) : (
        <Autocomplete
          disablePortal
          fullWidth
          renderOption={(props, option, { index }) => (
            <li {...props} key={index} data-value={option.id}>
              {option.label}
            </li>
          )}
          options={options}
          id={id}
          name={name || id}
          defaultValue={defaultValue || ""}
          value={value}
          onChange={onChange}
          renderInput={(params) => (
            <TextField
              {...params}
              fullWidth
              required={required}
              placeholder={placeholder}
              name={id}
              error={Error?.status}
              helperText={Error?.message}
              InputProps={{
                ...params.InputProps,

                startAdornment: (
                  <>
                    <InputAdornment position="start">{Icon}</InputAdornment>
                    {params.InputProps.startAdornment}
                  </>
                ),
              }}
              sx={{
                bgcolor: "var(--bg-input)",
              }}
            />
          )}
        />
      )}
    </FormControl>
  );
};

Select.propTypes = {
  id: propTypes.string.isRequired,
  name: propTypes.string,
  label: propTypes.string.isRequired,
  options: propTypes.any,
  defaultValue: propTypes.string,
  value: propTypes.string,
  Error: propTypes.object,
  Icon: propTypes.object,
  placeholder: propTypes.string,
  Button: propTypes.bool,
  required: propTypes.bool,
  onChange: propTypes.func,
  onSubmitNew: propTypes.func,
  loading: propTypes.bool,
};

export default Select;
