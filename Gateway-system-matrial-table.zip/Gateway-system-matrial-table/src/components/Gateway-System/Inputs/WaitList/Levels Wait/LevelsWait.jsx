import { useEffect } from "react";
import PropTypes from "prop-types";
import {
  createLevel,
  fetchLevels,
} from "@src/store/reducers/WaitList/View/ViewSlice";
import { SiLevelsdotfyi } from "react-icons/si";
import { useDispatch, useSelector } from "react-redux";
import Select from "../../Select";
import { ToastSuccess } from "@src/util/Toast";

const LevelsWait = ({ defaultValue, onChange }) => {
  const dispatch = useDispatch();

  const { levels, loading } = useSelector((state) => state.viewWaitList);

  useEffect(() => {
    dispatch(fetchLevels());
  }, [dispatch]);

  // create a new level
  const createNewLevels = (level) => {
    dispatch(createLevel({ level }))
      .unwrap()
      .then(({ message }) => {
        ToastSuccess(message);
        dispatch(fetchLevels());
      });
  };

  return (
    <Select
      id="level"
      label="Level"
      options={
        levels?.map((level) => ({
          id: level.id,
          label: level.level_name,
        })) || []
      }
      placeholder="select level"
      Icon={<SiLevelsdotfyi size={23} />}
      Button={true}
      defaultValue={defaultValue}
      required={true}
      onSubmitNew={createNewLevels}
      isLoading={loading}
      onChange={onChange}
    />
  );
};

LevelsWait.propTypes = {
  defaultValue: PropTypes.string,
  onChange: PropTypes.func,
};

export default LevelsWait;
