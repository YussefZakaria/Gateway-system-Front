import { useEffect } from "react";
import PropTypes from "prop-types";
import { ToastSuccess } from "@src/util/Toast";
import Select from "../../Select";
import { useDispatch, useSelector } from "react-redux";
import { MdPayment } from "react-icons/md";
import {
  createPaymentType,
  fetchPaymentType,
} from "@src/store/reducers/WaitList/View/ViewSlice";

const PaymentType = ({ defaultValue, onChange }) => {
  const dispatch = useDispatch();
  const { pymentType, loading } = useSelector((state) => state.viewWaitList);

  useEffect(() => {
    dispatch(fetchPaymentType());
  }, [dispatch]);

  // create a new Payment Type
  const createNewPaymentType = (payment_type) => {
    dispatch(createPaymentType({ payment_type }))
      .unwrap()
      .then(({ message }) => {
        ToastSuccess(message);
        dispatch(fetchPaymentType());
      });
  };

  return (
    <Select
      id="payment_type"
      name="Payment Type"
      label="Payment Type (Optional)"
      options={
        pymentType?.map((payment) => ({
          id: payment.id,
          label: payment.payment_title,
        })) || []
      }
      placeholder="Payment Type"
      Icon={<MdPayment size={23} />}
      Button={true}
      defaultValue={defaultValue}
      required={false}
      onSubmitNew={createNewPaymentType}
      isLoading={loading}
      onChange={onChange}
    />
  );
};

PaymentType.propTypes = {
  defaultValue: PropTypes.string,
  onChange: PropTypes.func,
};

export default PaymentType;
