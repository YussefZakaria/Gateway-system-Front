import { useEffect } from "react";
import PropTypes from "prop-types";
import Select from "../../Select";
import {
  clearError,
  createPreferableTime,
  fetchPreferableTime,
} from "@src/store/reducers/WaitList/View/ViewSlice";
import { ToastError, ToastSuccess } from "@src/util/Toast";
import { useDispatch, useSelector } from "react-redux";
import { SiCoursera } from "react-icons/si";

const PreferableTime = ({
  id,
  defaultValue,
  onChange,
  attend_type,
  age_group,
  Button,
  label,
  required,
}) => {
  const dispatch = useDispatch();

  const { preferableTime, loading, error } = useSelector(
    (state) => state.viewWaitList
  );

  useEffect(() => {
    attend_type &&
      age_group &&
      dispatch(fetchPreferableTime({ attend_type, age_group }));
  }, [dispatch, attend_type, age_group]);

  // create a new Preferable Time
  const createNewPreferableTime = (preferable_time) => {
    dispatch(createPreferableTime({ preferable_time, attend_type, age_group }))
      .unwrap()
      .then(({ message }) => {
        ToastSuccess(message);
        dispatch(fetchPreferableTime({ attend_type, age_group }));
      });
  };

  useEffect(() => {
    if (error) {
      ToastError(error);
      setTimeout(() => {
        dispatch(clearError());
      }, 5000);
    }
  }, [error, dispatch]);

  return (
    <Select
      id={id}
      name="Preferable Time"
      label={label || "Preferable time of slot (Optional)"}
      options={
        preferableTime?.map((time) => ({
          id: time.id,
          label: time.preferable_time,
        })) || []
      }
      placeholder="Preferable time"
      Icon={<SiCoursera size={23} />}
      Button={Button}
      defaultValue={defaultValue}
      required={required}
      isLoading={loading}
      onSubmitNew={createNewPreferableTime}
      onChange={onChange}
    />
  );
};

PreferableTime.propTypes = {
  id: PropTypes.string.isRequired,
  defaultValue: PropTypes.string,
  onChange: PropTypes.func,
  attend_type: PropTypes.string,
  age_group: PropTypes.string,
  Button: PropTypes.bool,
  required: PropTypes.bool,
  label: PropTypes.string,
};

export default PreferableTime;
