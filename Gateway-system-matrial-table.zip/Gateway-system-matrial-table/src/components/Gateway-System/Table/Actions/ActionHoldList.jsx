import { MenuItem } from "@mui/material";
import { AiOutlineDelete } from "react-icons/ai";
import { FaRegEdit } from "react-icons/fa";
import { MdMotionPhotosPaused } from "react-icons/md";
import PropTypes from "prop-types";
import { useDispatch } from "react-redux";
import {
  DeleteHoldList,
  fetchHoldlist,
} from "@src/store/reducers/HoldList/HoldListSlice";
import { ToastSuccess } from "@src/util/Toast";
import { MoveToWaitList } from "@src/store/reducers/HoldList/Move/MoveHoldListSlice";
import checkPermission from "@src/util/CheckPermission";
import { clearSelected } from "@src/store/Hook/clearSelection";

const ActionHoldList = ({ row, closeMenu, HandlerEdit }) => {
  const dispatch = useDispatch();

  // Delete one hold
  const onDelete = () => {
    dispatch(DeleteHoldList(row.id))
      .unwrap()
      .then(({ message }) => {
        ToastSuccess(message);
        dispatch(fetchHoldlist());
        dispatch(clearSelected());
      });
  };

  // Move hold to wait list
  const onMoveToWaitList = () => {
    dispatch(MoveToWaitList(row.id))
      .unwrap()
      .then(({ message }) => {
        ToastSuccess(message);
        dispatch(fetchHoldlist());
        dispatch(clearSelected());
      });
  };

  return (
    <>
      {checkPermission({
        name: "holdlist",
        children: [
          "update_trainees",
          "update_own_trainees",
          "update_trainees_by_branch",
        ],
      }) && (
        <MenuItem
          onClick={closeMenu}
          sx={{ gap: 1 }}
          onClickCapture={() => HandlerEdit(row)}
        >
          <FaRegEdit size={20} color="#2b6cb0" />
          Edit
        </MenuItem>
      )}
      {checkPermission({
        name: "holdlist",
        children: ["move_to_wait", "move_to_wait_by_branch"],
      }) && (
        <MenuItem
          onClick={closeMenu}
          sx={{ gap: 1 }}
          onClickCapture={onMoveToWaitList}
        >
          <MdMotionPhotosPaused size={20} color="#626189" />
          Move to wait
        </MenuItem>
      )}
      {checkPermission({
        name: "holdlist",
        children: [
          "delete_trainees",
          "delete_own_trainees",
          "delete_trainees_by_branch",
        ],
      }) && (
        <MenuItem onClick={closeMenu} sx={{ gap: 1 }} onClickCapture={onDelete}>
          <AiOutlineDelete size={20} color="brown" />
          Delete
        </MenuItem>
      )}
    </>
  );
};

ActionHoldList.propTypes = {
  row: PropTypes.object,
  closeMenu: PropTypes.func,
  HandlerEdit: PropTypes.func,
};

export default ActionHoldList;
