import { MaterialReactTable } from "material-react-table";
import Toolbar from "./Toolbar/Toolbar";
import PropTypes from "prop-types";
import IndexAction from "./Actions/IndexAction";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { useDispatch, useSelector } from "react-redux";
import { storedRowIds } from "@src/store/Hook/clearSelection";

const AdvancedTable = ({
  columns,
  rows,
  type,
  Actions,
  isLoading,
  bulkDelete,
  enableRowActions,
  enableRowSelection,
  LeftPinning,
  setBranch,
}) => {
  const dispatch = useDispatch();
  const { selectedRowIds } = useSelector((state) => state.clearSelection);

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <MaterialReactTable
        multiple
        columns={columns}
        data={rows}
        enableRowNumbers={true}
        enableColumnFilterModes={true}
        enableColumnPinning={true}
        enableFacetedValues={true}
        enableRowActions={enableRowActions}
        enableRowSelection={enableRowSelection}
        enableCellActions={true}
        enableDensityToggle={false}
        enableFullScreenToggle={false}
        enableEditing={true}
        editDisplayMode="cell"
        columnFilterDisplayMode="popover"
        positionToolbarAlertBanner="head-overlay"
        paginationDisplayMode="pages"
        // onRowSelectionChange={(rows) => {
        //   dispatch(storedRowIds(rows()));
        // }}
        muiSearchTextFieldProps={{
          size: "small",
          variant: "outlined",
        }}
        muiPaginationProps={{
          color: "primary",
          rowsPerPageOptions: [10, 20, 30],
        }}
        initialState={{
          columnPinning: {
            left: LeftPinning,
            right: ["mrt-row-actions"],
          },
          density: "medium",
          pagination: {
            pageIndex: 0,
            pageSize: 10,
          },
          showGlobalFilter: true,
        }}
        state={{
          isLoading: isLoading,
          // rowSelection: selectedRowIds,
        }}
        renderRowActionMenuItems={({ closeMenu, row }) => [
          <div key={row.id}>
            <IndexAction row={row.original} closeMenu={() => closeMenu()}>
              {Actions}
            </IndexAction>
          </div>,
        ]}
        renderTopToolbar={({ table }) => (
          <Toolbar
            table={table}
            type={type}
            csvData={rows}
            bulkDelete={bulkDelete}
            setBranch={setBranch}
          />
        )}
        muiTablePaperProps={{
          sx: {
            width: "100%",
            overflow: "auto !important",
            borderRadius: "10px",
            backgroundColor: "var(--bg-sidebar) !important",
            "& .MuiTypography-root": {
              color: "var(--text-black) !important",
            },
            "& .MuiSvgIcon-root": {
              color: "var(--text-gray) !important",
            },
            "& .css-118d58w-MuiButtonBase-root-MuiTableSortLabel-root .MuiTableSortLabel-icon":
              {
                color: "var(--text-black) !important",
              },
            "& .css-142h5t9-MuiFormLabel-root-MuiInputLabel-root": {
              color: "var(--text-black) !important",
            },
            "& .MuiInput-input": {
              color: "var(--text-black) !important",
            },
            "& .MuiFormHelperText-root": {
              color: "var(--text-black) !important",
            },
            "& .css-1io6e0z-MuiTableRow-root td[data-pinned=true]:before": {
              background: "var(--bg-sidebar) !important",
              color: "var(--text-black) !important",
            },
            "& .css-gcpdls-MuiTableCell-root[data-pinned=true]:before": {
              background: "var(--bg-sidebar) !important",
              color: "var(--text-black) !important",
            },
            "& .css-1yg0dk4-MuiInputBase-root-MuiOutlinedInput-root": {
              color: "var(--text-black) !important",
            },
            "& .css-10q6jkf-MuiTableCell-root[data-pinned=true]:before": {
              background: "var(--bg-sidebar) !important",
            },
            ".css-1vbcmy6-MuiTableRow-root td[data-pinned=true]:before": {
              background: "var(--bg-sidebar) !important",
              color: "var(--text-black) !important",
            },
          },
        }}
        muiTableContainerProps={{
          sx: {
            backgroundColor: "var(--bg-sidebar) !important",
            "& .css-h6lbh0-MuiTableCell-root[data-pinned=true]:before": {
              backgroundColor: "var(--bg-sidebar) !important",
            },
          },
        }}
        muiTableHeadRowProps={{
          sx: {
            backgroundColor: "var(--bg-sidebar) !important",
            "& .MuiTableCell-root": {
              backgroundColor: "var(--bg-sidebar) !important",
              color: "var(--text-black) !important",
            },
          },
        }}
        muiTableBodyRowProps={{
          sx: {
            backgroundColor: "var(--bg-sidebar) !important",
            "& .MuiTableCell-root": {
              color: "var(--text-black) !important",
            },
          },
        }}
        muiBottomToolbarProps={{
          sx: {
            backgroundColor: "var(--bg-sidebar) !important",
            "& .MuiAlert-root": {
              backgroundColor: "var(--bg-sidebar) !important",
              color: "var(--text-black) !important",
            },
          },
        }}
      />
    </LocalizationProvider>
  );
};

AdvancedTable.propTypes = {
  columns: PropTypes.arrayOf(PropTypes.object).isRequired,
  rows: PropTypes.any,
  type: PropTypes.string,
  Actions: PropTypes.any,
  isLoading: PropTypes.bool,
  bulkDelete: PropTypes.func,
  enableRowActions: PropTypes.bool,
  enableRowSelection: PropTypes.bool,
  LeftPinning: PropTypes.array,
  setBranch: PropTypes.func,
};

export default AdvancedTable;
