import { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { Box, Button } from "@mui/material";
import Select from "@src/components/Gateway-System/Inputs/Select";
import {
  clearError,
  createAssignClass,
  fetchLevelAssignClass,
  fetchTimeSlotAssignClass,
  updateClassesAssignClass,
} from "@src/store/reducers/WaitList/AssignClass/AssignClassSlice";
import { useDispatch, useSelector } from "react-redux";
import { fetchWaitList } from "@src/store/reducers/WaitList/WaitListSlice";
import { ToastError, ToastSuccess } from "@src/util/Toast";
import Spinner from "@src/components/Gateway-System/Spinner/Spinner";
import Alert from "@src/components/feedback/Alert/Alert";

const AssignClass = ({
  getAssignId,
  selectAllIds,
  closeAssignClass,
  type,
  handlerBulkDispatch,
}) => {
  const [class_id, setClassID] = useState("");
  const [assign_id, setAssignId] = useState({
    trainee_id: getAssignId,
  });
  const [attend_type, setAttendType] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const dispatch = useDispatch();
  const { level, timeSlot, classes, error, loading } = useSelector(
    (state) => state.assginClass
  );

  // store trainees in state
  useEffect(() => {
    if (selectAllIds) {
      setAssignId((prev) => ({ ...prev, trainees: selectAllIds }));
    }
  }, [selectAllIds, dispatch]);

  // View Assign class
  useEffect(() => {
    if (type !== "bulkAssignClass") {
      attend_type &&
        dispatch(
          fetchTimeSlotAssignClass({ trainee_id: getAssignId, attend_type })
        );
      dispatch(fetchLevelAssignClass({ trainee_id: getAssignId }));
      dispatch(updateClassesAssignClass(assign_id));
    }
  }, [dispatch, attend_type, getAssignId, type, assign_id]);

  // View bulk Assign class
  useEffect(() => {
    if (type === "bulkAssignClass") {
      attend_type &&
        dispatch(
          fetchTimeSlotAssignClass({
            trainees: selectAllIds,
            attend_type,
          })
        );
      dispatch(fetchLevelAssignClass({ trainees: selectAllIds }));
      if (assign_id?.trainees?.length > 0) {
        dispatch(updateClassesAssignClass(assign_id));
      }
    }
  }, [dispatch, attend_type, getAssignId, type, assign_id, selectAllIds]);

  const handlerDispatch = () => {
    dispatch(createAssignClass({ id: getAssignId, class_id }))
      .unwrap()
      .then(({ message }) => {
        ToastSuccess(message);
        dispatch(fetchWaitList());
        closeAssignClass();
      });
  };

  const handlerONBulk = () => {
    handlerBulkDispatch(class_id);
    closeAssignClass();
  };

  const handlerSubmitted = (event) => {
    event.preventDefault();

    const Trainees = classes?.find((Class) => Class.id === class_id);

    if (Trainees?.num_of_trainees >= 10) {
      setIsOpen(true);
      return;
    } else {
      type === "bulkAssignClass" ? handlerONBulk() : handlerDispatch();
    }
  };

  // Change All select classType -  time - level  Assign id
  const handleChangeAssignID = (data) => {
    if (data.value) {
      setAssignId((prev) => ({ ...prev, [data.name]: data.value }));
    } else {
      setAssignId((prev) => ({ ...prev, [data.name]: "" }));
    }
  };

  // filter class
  useEffect(() => {
    if (assign_id?.class_type || assign_id?.level || assign_id?.time_slot) {
      dispatch(updateClassesAssignClass(assign_id));
    }
  }, [assign_id, dispatch]);

  // show error message
  useEffect(() => {
    if (error) {
      ToastError(error.message);

      setTimeout(() => {
        dispatch(clearError());
      }, 5000);
    }
  }, [error, dispatch]);

  return (
    <>
      {isOpen && (
        <Alert
          isOpen={isOpen}
          zIndex={999999}
          Continue={() =>
            type === "bulkAssignClass" ? handlerONBulk() : handlerDispatch()
          }
          Cancel={() => setIsOpen(false)}
          isLoading={loading}
        />
      )}

      <Box
        component={"form"}
        onSubmit={handlerSubmitted}
        sx={{
          display: "flex",
          flexDirection: "column",
          gap: 2,
          margin: "20px 0 0",
        }}
      >
        <Select
          id="class_type"
          label="Class Type"
          options={[
            { id: 1, label: "Online" },
            { id: 2, label: "Offline" },
            { id: 3, label: "Hybrid" },
          ]}
          placeholder="Choose Class Type"
          onChange={(e, v) => {
            handleChangeAssignID({
              value: v?.label,
              name: "class_type",
            });
            setAttendType(v?.label);
          }}
        />

        <Select
          id="time_slot"
          label="Time Slot"
          options={
            timeSlot?.map((time) => ({ id: time.id, label: time.time_slot })) ||
            []
          }
          placeholder="Choose Time Slot"
          onChange={(e) =>
            handleChangeAssignID({
              value: Number(e.target.dataset.value) || "",
              name: "time_slot",
            })
          }
        />
        <Select
          id="level"
          label="Level"
          options={
            level?.map((level) => ({
              id: level.id,
              label: level.level_name,
            })) || []
          }
          placeholder="Choose Level"
          onChange={(e) =>
            handleChangeAssignID({
              value: Number(e.target.dataset.value),
              name: "level",
            })
          }
        />

        <Select
          id="classes"
          label="Classes"
          options={
            classes?.map((classes) => ({
              id: classes.id,
              label: `${classes.class_name} - No. ${classes.num_of_trainees}`,
            })) || []
          }
          placeholder="Choose Classes"
          required={true}
          onChange={(e) => setClassID(Number(e.target.dataset.value))}
        />

        <Button type="submit" variant="contained" sx={{ gap: 1 }}>
          {loading && <Spinner />} Assign
        </Button>
      </Box>
    </>
  );
};

AssignClass.propTypes = {
  getAssignId: PropTypes.any,
  selectAllIds: PropTypes.array,
  closeAssignClass: PropTypes.func,
  type: PropTypes.string,
  handlerBulkDispatch: PropTypes.func,
};

export default AssignClass;
