import { useEffect, useState } from "react";
import styles from "@styles/styles.module.css";
import PathName from "@components/Gateway-System/PathName/PathName";
import AdvancedTable from "@src/components/Gateway-System/Table/AdvancedTable";
import { CloumnsHoldList } from "@src/shared/CloumnsTables";
import ActionHoldList from "@src/components/Gateway-System/Table/Actions/ActionHoldList";
import { useDispatch, useSelector } from "react-redux";
import {
  clearError,
  fetchHoldlist,
  UpdateHoldList,
} from "@src/store/reducers/HoldList/HoldListSlice";
import { ToastError, ToastSuccess } from "@src/util/Toast";
import Modals from "@src/components/Gateway-System/Modals/Modals";
import FormTrainee from "@src/components/forms/WaitList/Trainee/FormTrainee";
import { Navigate, useOutletContext } from "react-router-dom";
import checkPermission from "@src/util/CheckPermission";
import { Helmet } from "react-helmet";

const HoldList = () => {
  const [isOpenEdit, setIsOpenEdit] = useState({ isOpen: false });
  const [branch, setBranch] = useState("");

  const context = useOutletContext();
  const dispatch = useDispatch();

  const { holdList, error, isLoading } = useSelector((state) => state.holdList);

  useEffect(() => {
    dispatch(fetchHoldlist(branch));
  }, [dispatch, branch]);

  const HandlerEdit = (data) => {
    setIsOpenEdit({ isOpen: true, trainee: data });
  };

  const onSubmitEdit = (data) => {
    dispatch(UpdateHoldList({ id: isOpenEdit?.trainee.id, data }))
      .unwrap()
      .then(({ message }) => {
        ToastSuccess(message);
        dispatch(fetchHoldlist(branch));
        setIsOpenEdit({ isOpen: false });
      });
  };

  // Show error message
  useEffect(() => {
    if (error) {
      ToastError(error?.message);
      setTimeout(() => {
        dispatch(clearError());
      }, 5000);
    }
  }, [error, dispatch]);

  if (
    !checkPermission({
      name: "holdlist",
      children: [
        "view_trainees",
        "view_own_trainees",
        "view_trainees_by_branch",
      ],
    })
  ) {
    return <Navigate to="*" replace />;
  }

  return (
    <div className={styles.containerPage}>
      <Helmet>
        <meta charSet="utf-8" />
        <title>{`${context} | HoldList`}</title>
      </Helmet>

      <PathName path="HoldList" />
      <div className={styles.containerPage_content}>
        {/* Edit Row Trainee */}
        {checkPermission({
          name: "holdlist",
          children: [
            "update_trainees",
            "update_own_trainees",
            "update_trainees_by_branch",
          ],
        }) && (
          <Modals
            isOpen={isOpenEdit.isOpen}
            handleClose={() => setIsOpenEdit({ isOpen: false })}
          >
            <FormTrainee
              onSubmit={onSubmitEdit}
              isLoading={isLoading}
              edit={true}
              trainee={isOpenEdit?.trainee}
              type="holdlist"
            />
          </Modals>
        )}

        {/* Table Hold List */}
        <div className={styles.table} style={{ marginTop: "80px" }}>
          <AdvancedTable
            columns={CloumnsHoldList()}
            rows={holdList?.trainees || []}
            Actions={<ActionHoldList HandlerEdit={HandlerEdit} />}
            isLoading={isLoading}
            type="holdlist"
            enableRowSelection={true}
            enableRowActions={true}
            setBranch={setBranch}
          />
        </div>
      </div>
    </div>
  );
};

export default HoldList;
