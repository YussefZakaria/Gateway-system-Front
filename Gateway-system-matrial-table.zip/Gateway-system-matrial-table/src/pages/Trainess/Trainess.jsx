import styles from "@styles/styles.module.css";
import PathName from "@components/Gateway-System/PathName/PathName";
import AdvancedTable from "@src/components/Gateway-System/Table/AdvancedTable";
import { CloumnsTrainess } from "@src/shared/CloumnsTables";
import ActionTrainess from "@src/components/Gateway-System/Table/Actions/ActionTrainess";
import { useDispatch, useSelector } from "react-redux";
import {
  clearError,
  fetchTrainees,
} from "@src/store/reducers/Trainees/TraineesSlice";
import { useEffect, useState } from "react";
import { ToastError } from "@src/util/Toast";
import { Navigate, useOutletContext } from "react-router-dom";
import checkPermission from "@src/util/CheckPermission";
import { Helmet } from "react-helmet";

const Trainess = () => {
  const [branch, setBranch] = useState("");

  const context = useOutletContext();
  const dispatch = useDispatch();
  const { trainees, error, isLoading } = useSelector((state) => state.Trainees);

  useEffect(() => {
    dispatch(fetchTrainees(branch));
  }, [dispatch, branch]);

  // Show error message
  useEffect(() => {
    if (error) {
      ToastError(error?.message);

      setTimeout(() => {
        dispatch(clearError());
      }, 5000);
    }
  }, [error, dispatch]);

  if (
    !checkPermission({
      name: "trainees",
      children: ["view_trainees", "view_trainees_by_branch"],
    })
  ) {
    return <Navigate to="*" replace />;
  }

  return (
    <div className={styles.containerPage}>
      <Helmet>
        <meta charSet="utf-8" />
        <title>{`${context} | Trainees`}</title>
      </Helmet>

      <PathName path="Trainess" />
      <div className={styles.containerPage_content}>
        {/* Table Pending Users */}
        <div className={styles.table} style={{ marginTop: "80px" }}>
          <AdvancedTable
            columns={CloumnsTrainess()}
            rows={trainees || []}
            Actions={<ActionTrainess />}
            isLoading={isLoading}
            enableRowSelection={false}
            enableRowActions={true}
            setBranch={setBranch}
          />
        </div>
      </div>
    </div>
  );
};

export default Trainess;
