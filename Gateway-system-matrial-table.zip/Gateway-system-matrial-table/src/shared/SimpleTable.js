export const pendingUserCloumns = [
  "Full Name",
  "Email",
  "Mobile",
  "Second Mobile",
  "Country",
  "Branch",
];
export const HoldListCloumns = [
  "Full Name",
  "Notes",
  "Mobile",
  "Second Mobile",
  "Branch",
  "Level",
  "Attend type",
];

export const PendingTestCloumns = [
  "Full Name",
  "Mobile",
  "Second Mobile",
  "Country",
  "Age Group",
  "Attend Type",
  "Test Date",
];

export const waitListCloumns = [
  "Full Name",
  "Mobile",
  "Second Mobile",
  "Level",
  "Attend Type",
  "Payment Type",
  "Moved Date",
];
