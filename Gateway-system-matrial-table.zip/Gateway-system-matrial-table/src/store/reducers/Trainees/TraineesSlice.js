import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

// Get All Trainess
export const fetchTrainees = createAsyncThunk(
  "trainess/fetchTrainees",
  async (branch, thunkAPI) => {
    const { rejectWithValue } = thunkAPI;
    try {
      const res = await axios.put(
        `${import.meta.env.VITE_API_URL}/dashboard/trainees`,
        { branch }
      );
      return res.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Get single Trainees
export const fetchSingleTrainee = createAsyncThunk(
  "trainess/fetchSingleTrainee",
  async (trainee_id, thunkAPI) => {
    const { rejectWithValue } = thunkAPI;
    try {
      const res = await axios.put(
        `${import.meta.env.VITE_API_URL}/dashboard/trainees/${trainee_id}`
      );
      return res.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// fetch Search for Trainees
export const fetchSearch = createAsyncThunk(
  "trainess/fetchSearchTrainees",
  async (searchQuery, thunkAPI) => {
    const { rejectWithValue } = thunkAPI;
    try {
      const res = await axios.get(
        `${import.meta.env.VITE_API_URL}/dashboard/search?query=${searchQuery}`
      );
      return res.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

const TrainessSlice = createSlice({
  name: "trainess",
  initialState: {
    trainees: [],
    single_trainee: {},
    Search: [],
    isLoading: false,
    error: null,
    errorSearch: null,
  },
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchTrainees.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchTrainees.fulfilled, (state, action) => {
        state.isLoading = false;
        state.trainees = action.payload;
      })
      .addCase(fetchTrainees.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });

    // get single trainee
    builder
      .addCase(fetchSingleTrainee.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchSingleTrainee.fulfilled, (state, action) => {
        state.isLoading = false;
        state.single_trainee = action.payload;
      })
      .addCase(fetchSingleTrainee.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });

    // fetch search for trainees
    builder
      .addCase(fetchSearch.fulfilled, (state, action) => {
        state.Search = action.payload;
      })
      .addCase(fetchSearch.rejected, (state, action) => {
        state.errorSearch = action.payload;
      });
  },
});

export const { clearError } = TrainessSlice.actions;

export default TrainessSlice.reducer;
