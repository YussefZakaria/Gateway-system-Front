
export const onSubmit = (event) => {
  event.preventDefault();
  const formData = new FormData(event.currentTarget);
};

export const onEdit = () => {};

export const onDelete = () => {};
